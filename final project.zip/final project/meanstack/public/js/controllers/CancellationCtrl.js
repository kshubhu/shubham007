sampleApp.controller('cancelController', function($scope, $http, $log) {

  $scope.tagline = 'cancel tickets ';

  var getDetails = function() {
       
    $http({
      method: 'PUT',
      url: 'assign/addAssign/' + $scope.id,
      headers: {'Content-Type': 'application/json'},
      data: angular.fromJson(assignObj)
    })
      };
    });